import Q1 from "./COS/Q1"
import Q3 from "./COS/Q3"
import Q5 from "./COS/Q5"


function App() {


  return (
    <> 
      <Q1 />
      <Q3 />
      <Q5 />
    </>
  )
}

export default App
