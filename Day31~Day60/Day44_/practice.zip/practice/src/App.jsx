import Q1 from "./Q1"
import Q4 from "./Q4"


function App() {


  return (
    <>
      <Q1 />
      <Q4 />
    </>
  )
}

export default App
