import Q1 from "./Test/Q1"
import Q2 from "./Test/Q2"


function App() {


  return (
    <>
      <Q1 />
      <Q2 />
    </>
  )
}

export default App
