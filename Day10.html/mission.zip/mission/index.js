function closeModal() {
  document.getElementById("wrap").classList.add("hidden");
}